import path from "path";
import { WebSocketServer } from "ws";
import fastify from "fastify";
import staticPlugin from "@fastify/static";
import formbodyPlugin from "@fastify/formbody";
import viewPlugin from "@fastify/view";
import handlebars from "handlebars";

// Инициализируем Fastify
const app = fastify({
  logger: false,
});

// Настройка статических файлов
app.register(staticPlugin, {
  root: path.join(process.cwd(), "public"),
  prefix: "/",
});

// Поддержка парсинга форм
app.register(formbodyPlugin);

// Поддержка шаблонизатора Handlebars
app.register(viewPlugin, {
  engine: {
    handlebars,
  },
});

// Маршрут главной страницы
app.get("/", function (_, reply) {
  return reply.sendFile("index.html");
});

// Создаем WebSocket-сервер
const wss = new WebSocketServer({ 
  noServer: true
});

app.server.on('upgrade', (request, socket, head) => {
  wss.handleUpgrade(request, socket, head, (ws) => {
    wss.emit('connection', ws, request);
  });
});

// Глобальное состояние
let gameState = {
  activeColor: null,
  endTime: null
};

// Обработка подключения нового клиента
wss.on("connection", (ws) => {
  console.log("Новый клиент подключен");

  // Отправляем текущее состояние новому клиенту
  if (gameState.activeColor && gameState.endTime > Date.now()) {
    ws.send(JSON.stringify({
      type: 'sync',
      color: gameState.activeColor,
      remainingTime: Math.ceil((gameState.endTime - Date.now()) / 1000)
    }));
  }

  // Обработка входящих сообщений
  ws.on("message", (message) => {
    const data = JSON.parse(message);
    console.log("Получено сообщение:", data);

    if (data.type === 'activate' && !gameState.activeColor) {
      gameState.activeColor = data.color;
      gameState.endTime = Date.now() + 10000; // 10 секунд

      // Отправляем всем клиентам
      const broadcastData = JSON.stringify({
        type: 'sync',
        color: gameState.activeColor,
        remainingTime: 10
      });

      wss.clients.forEach((client) => {
        if (client.readyState === 1) {
          client.send(broadcastData);
        }
      });

      // Сброс состояния через 10 секунд
      setTimeout(() => {
        gameState.activeColor = null;
        gameState.endTime = null;
        
        wss.clients.forEach((client) => {
          if (client.readyState === 1) {
            client.send(JSON.stringify({ type: 'reset' }));
          }
        });
      }, 10000);
    }
  });

  // Обработка отключения клиента
  ws.on("close", () => {
    console.log("Клиент отключен");
  });
});

// Запускаем сервер
app.listen({ port: 3000, host: "0.0.0.0" }, function (err, address) {
  if (err) {
    console.error(err);
    process.exit(1);
  }
  console.log(`Ваше приложение запущено на ${address}`);
});